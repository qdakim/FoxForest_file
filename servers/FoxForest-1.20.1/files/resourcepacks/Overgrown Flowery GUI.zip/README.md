# Overgrown Flowery GUI
A Resource Pack overhauling the Minecraft UI bueatifying it with flowery vines and lavender.
https://discord.gg/H9V6FuVGfT